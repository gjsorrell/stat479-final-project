#!/bin/bash
mkdir -p log
mkdir -p error
mkdir -p output
