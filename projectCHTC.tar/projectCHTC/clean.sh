#!/bin/bash
rm *.tsv
rm -r error log output
rm submit.dag.*