#!/bin/bash
cat clean_*.tsv > merge.tsv
rm *v1_00.tsv
